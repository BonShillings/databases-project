class Location < ActiveRecord::Base
    belongs_to: restaurant
end
