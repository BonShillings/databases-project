class Rater < ActiveRecord::Base
    has_many :ratings
end
