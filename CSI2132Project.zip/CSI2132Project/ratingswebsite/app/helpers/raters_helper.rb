module RatersHelper
end
