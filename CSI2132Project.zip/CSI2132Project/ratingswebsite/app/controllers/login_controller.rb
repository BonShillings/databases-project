class LoginController < ApplicationController
  def homepage
  end
end
