require 'test_helper'

class MenuitemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
