require 'test_helper'

class RatingItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
